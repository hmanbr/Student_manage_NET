﻿global using System.ComponentModel.DataAnnotations;
global using Microsoft.EntityFrameworkCore;
global using G3.Models;
global using G3.Dtos;
global using G3.Services;
global using G3.ActionFilters;
