﻿namespace G3.Models
{
    public class UserSettingViewModel
    {
        public User User { get; set; }
        public List<Setting> Settings { get; set; }
    }
}
